package com.tr.invitaz.model;

public class EventState {
}
