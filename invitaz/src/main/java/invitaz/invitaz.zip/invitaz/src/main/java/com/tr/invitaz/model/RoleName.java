package com.tr.invitaz.model;

public enum RoleName {

    ROLE_USER,
    ROLE_ADMIN
}
